This directory contains M-files for the solution of all the examples 
and exercises in the tutorial
  L.F. Shampine, J. Kierzenka, and M.W. Reichelt, Solving Boundary 
  Value Problems for Ordinary Differential Equations in MATLAB with 
  BVP4C.

The M-files in this directory have been updated to take advantage 
of features available in MATLAB 6.5 (R13). In particular, the function 
BVPVAL (obsoleted in MATLAB 6.5) has been replaced by calls to DEVAL.

We acknowledge the work of Jared Carlson, who converted the examples to 
the MATLAB 6.5 format.
